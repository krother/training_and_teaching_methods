
# Creating Tables

![](penguins.png)

**An example lesson plan featuring cute penguins**

## Goal

Participants load a CSV file with penguin data into SQL.

----

## Prerequisites

Participants need to have **PostgreSQL** installed and have access via `psql`.

----

## Key Concepts

* table
* columns
* data types
* constraints
* loading data

----

## Lesson Plan

| time (min) | phase | description |
|------------|-------|-------------|
|   0  | warm-up | say hello and announce title of the lesson |
|   2  | warm-up | ask students to name a few penguins they know |
|  10  | warm-up | show the CSV file, introduce the problem/goal |
|  15  | new content | show and execute the CREATE TABLE statement |
|  35  | new content | show the mind map |
|  40  | BREAK | - |
|  50  | apply content | students load the bigger penguin file in pairs |
|  70  | wrap-up | discuss common problems you found during the exercise |
|  85  | wrap-up | show the mind map again |

----

## Material

* image with 3 penguin species (`penguins.png`)
* example SQL CREATE TABLE statement (`penguins.sql`)
* mind map (`create_table.png`)
* CSV file with small penguin dataset (50 rows, 5 columns) (`penguins.csv`)
* Excel file with small penguin dataset (`penguins.xslx`)
* CSV file with big penguin dataset (`penguins_big.csv`)
* PDF with exercises (`exercises.pdf`)

----

## Backup Plans

* exercises 1-4 are easy, 5 gives room for quick students to transfer to a new example
* if participants are unfamiliar with relational databases, open the Excel sheet and discuss problems with data consistency
